batch_aal: spm8 batch interface GUI 

Install
---------
To install follow either of the two ways:

1. Extract archive to a folder - batch_aal and copy the folder in your spm8/toolbox folder as batch_aal.
2. Extract archive to a folder - batch_aal and copy and overwrite aal toolbox in your spm8/toolbox (aal can still be used from drop down menu from spm8 menu).

Testing
----------
The scripts are tested on Matlab 2012a on a LINUX/Ubuntu 12.04 and Matlab 2010a under Windows 7 environments.


